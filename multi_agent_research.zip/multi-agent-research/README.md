# Multi-Agent Research System

A multi-agent research system powered by the Anthropic Claude API, where four specialized agents — Planner, Researcher, Analyst, and Writer — collaborate in a pipeline to research, analyze, and synthesize answers to any question, with a clean responsive UI.

## Agents

| Agent | Role |
|-------|------|
| Orchestrator | Coordinates the pipeline |
| Planner | Decomposes the question into sub-questions |
| Researcher | Gathers facts and perspectives |
| Analyst | Identifies patterns and insights |
| Writer | Synthesizes a final summary |

## Setup

1. Open `index.html` in your code editor.
2. Replace `YOUR_ANTHROPIC_API_KEY` near the top of the `<script>` with your actual key:
   ```js
   const API_KEY = 'sk-ant-...';
   ```
3. Open `index.html` in your browser — no build step needed.

## Usage

Enter any research question in the input field and click **Research**. The agents will run sequentially and display their outputs in real time.

## ⚠️ API Key Warning

This project calls the Anthropic API directly from the browser. For personal or demo use this is fine, but for a public deployment you should proxy the API call through a backend to keep your key secret.

## Tech Stack

- Vanilla HTML, CSS, JavaScript
- Anthropic Claude API (`claude-sonnet-4-6`)
- Tabler Icons (CDN)

## License

MIT
